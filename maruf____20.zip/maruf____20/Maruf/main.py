import tkinter as tk
from tkinter import PhotoImage


class SampleAPP(tk.Tk):
    def __init__(self, *arg, **kwargs):
        tk.Tk.__init__(self, *arg, **kwargs)
        container = tk.Frame(self)
        container.pack(side="top", fill="both", expand=True)
        container.grid_rowconfigure(0, weight=1)
        container.grid_columnconfigure(0, weight=1)

        self.frames = {}
        for F in (StartPage, MenuPage, EndPage, ChooseBack):
            page_name = F.__name__
            frame = F(parent=container, controller=self)
            self.frames[page_name] = frame

            frame.grid(row=0, column=0, sticky="nsew")

            self.show_frame("StartPage")

    def show_frame(self, page_name):
        frame = self.frames[page_name]
        frame.tkraise()


class StartPage(tk.Frame):
    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)
        self.controller = controller
        self.controller.title('Magazin')
        self.controller.state('zoomed')
        self.controller.geometry('1250x650')
        self.controller.resizable(0, 0)


        self.backGroundImage = PhotoImage(file=r"img/shop3.png")
        self.backGroundImage_Label = tk.Label(self, width=1350, height=800, image=self.backGroundImage)
        self.backGroundImage_Label.place(x=0, y=0)

        big_label = tk.Label(self, text=('INEL \nMarket'), font=('Bernard MT Condensed', 50, 'bold'), fg="#000"
                              , bg="#999")
        big_label.pack(pady=40)


        login_label = tk.Label(self, text="ENTER YOUR LOGIN", font=('Bernard MT Condensed', 15, 'bold'), fg="#555",
                               bg="#fff")
        login_label.pack()

        my_login = tk.StringVar()
        login_entry = tk.Entry(self, textvariable=my_login, font=('Bernard MT Condensed', 15, 'bold'), fg="#333",
                               bg="#fff")
        login_entry.pack(pady=30)


        password_label = tk.Label(self, text="ENTER YOUR PASSWORD", font=('Bernard MT Condensed', 15, 'bold'),
                                  fg="#555", bg="#fff")
        password_label.pack(pady=30)

        my_password = tk.StringVar()
        password_entry = tk.Entry(self, textvariable=my_password, font=('Bernard MT Condensed', 15, 'bold'), fg="#333",
                                  bg="#fff")
        password_entry.pack()

        def check_password():
            if my_password.get() == "2222" and my_login.get() == "maruf" :
                controller.show_frame('ChooseBack')

            elif my_password.get() == "2222" and my_login.get() == "maruf" :
                right_label['text'] = "Wrong passport "
                right_label['text'] = "Wrong password "
            elif my_password.get() != "2222" and my_login.get() == "maruf" :
                right_label['text'] = "Wrong password "
            elif my_password.get() == "2222" and my_login.get() != "maruf" :
                right_label['text'] = "Wrong login "
            elif my_password.get() == "" and my_login.get() == "" :
                right_label['text'] = "FILL IN THE BLANKS!!! "
            else:
                right_label['text'] = "Wrong login or password "

        password_button = tk.Button(self, text="click", command=check_password,
                                    font=('Bernard MT Condensed', 15, 'bold'), fg="#555", bg="#999", width='25')

        password_button.pack(pady=40)
        right_label = tk.Label(self, font=('Bernard MT Condensed', 50, 'bold'), fg="red", bg="#eee")
        right_label.pack()

class ChooseBack(tk.Frame):
    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent, bg="black")
        self.controller = controller


        self.backGroundImage = PhotoImage(file=r"img/fruit2.png")
        self.backGroundImage_Label = tk.Label(self, width=1350, height=800, image=self.backGroundImage)
        self.backGroundImage_Label.place(x=0, y=0)
        def return_page():
            controller.show_frame('StartPage')

        return_button = tk.Button(self, text="Orqaga", command=return_page,
                                  font=('Bernard MT Condensed', 15, 'bold'), fg="red", bg="#000")
        return_button.pack()
        def choose_fruit():
            controller.show_frame('MenuPage')
        cash_button = tk.Button(self, text="Sabzavot", command=choose_fruit,
                                font=('Bernard MT Condensed', 40, 'bold'), fg="#333", bg="orange", width='25')
        cash_button.place(x=70, y=600)

        def choose_vegatables():
            controller.show_frame('EndPage')
        cash_button = tk.Button(self, text="Meva", command=choose_vegatables,
                                font=('Bernard MT Condensed', 40, 'bold'), fg="#333", bg="green", width='25')
        cash_button.place(x=670, y=600)





class MenuPage(tk.Frame):
    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent, bg="black")
        self.controller = controller


        self.backGroundImage = PhotoImage(file=r"img/vegetables.png")
        self.backGroundImage_Label = tk.Label(self, width=1350, height=800, image=self.backGroundImage)
        self.backGroundImage_Label.place(x=0, y=0)
        big_lable = tk.Label(self, text="Sabzavot bo'limi", font=('Bernard MT Condensed', 50, 'bold'),
                             fg="black", bg="green")
        big_lable.place(x=0 ,y=0)

        def return_page():
            controller.show_frame('ChooseBack')

        return_button = tk.Button(self, text="Orqaga", command=return_page,
                                  font=('Bernard MT Condensed', 15, 'bold'), fg="red", bg="#000")
        return_button.pack()

        in_money_label = tk.Label(self, text="Sabzavot", font=('Bernard MT Condensed', 15, 'bold'),
                                  fg="pink", bg="black")
        in_money_label.place(x=100,y=100)
        in_money = tk.StringVar()

        in_money_entry = tk.Entry(self, textvariable=in_money, font=('Bernard MT Condensed', 15, 'bold'), fg="#555", bg="#999")
        in_money_entry.place(x=100, y=150)

        def choose_sabzavot():
            global new_cash
            if in_money.get()=="sabzi":
                new_cash = int(my_cash.get()) * int(2500)
                cash_label['text'] = new_cash
            elif in_money.get()=="piyoz":
                new_cash = int(my_cash.get()) * int(1000)
                cash_label['text'] = new_cash
            elif in_money.get()=="kartoshka":
                new_cash = int(my_cash.get()) * int(3200)
                cash_label['text'] = new_cash
            elif in_money.get()=="pamidor":
                new_cash = int(my_cash.get()) * int(4400)
                cash_label['text'] = new_cash
            else :
                new_cash = int(my_cash.get())
                cash_label['text'] = new_cash
        cash_label = tk.Label(self, text="Miqdor(kg)", font=('Bernard MT Condensed', 15, 'bold'),
                      fg="pink", bg="black")
        cash_label.place(x=100 , y=250)
        my_cash = tk.IntVar()
        cash_entry = tk.Entry(self, textvariable=my_cash, font=('Bernard MT Condensed', 15, 'bold'), fg="pink", bg="#999")
        cash_entry.place(x=100, y=300)


        cash_label = tk.Label(self, font=('Bernard MT Condensed', 40, 'bold'),
                      fg="pink", bg="black")
        cash_label.place(x=100,y=550)

        cash_button = tk.Button(self, text="kiritish", command=choose_sabzavot,
                        font=('Bernard MT Condensed', 15, 'bold'), fg="pink", bg="black", width='25')
        cash_button.place(x=100, y=400)

        text1_label = tk.Label(self, text="sabzi:       2500", font=('Bernard MT Condensed', 25, 'bold'),
                              fg="#000", bg="#fff")
        text1_label.place(x=800, y=100)
        text2_label = tk.Label(self, text="kartoshka:   3200", font=('Bernard MT Condensed', 25, 'bold'),
                              fg="#000", bg="#fff")
        text2_label.place(x=800, y=200)
        text3_label = tk.Label(self, text="piyoz:       1000", font=('Bernard MT Condensed', 25, 'bold'),
                              fg="#000", bg="#fff")
        text3_label.place(x=800, y=300)
        text4_label = tk.Label(self, text="pamidor:     4400", font=('Bernard MT Condensed', 25, 'bold'),
                              fg="#000", bg="#fff")
        text4_label.place(x=800, y=400)
class EndPage(tk.Frame):
    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent, bg="#FF7578")
        self.controller = controller
        self.controller.title('Magazin')

        self.backGroundImage = PhotoImage(file=r"img/shop8.png")
        self.backGroundImage_Label = tk.Label(self, width=1350, height=800, image=self.backGroundImage)
        self.backGroundImage_Label.place(x=0, y=0)
        big_lable = tk.Label(self, text="Meva bo'limi", font=('Bernard MT Condensed', 50, 'bold'), fg="green",
                             bg="#fff")
        big_lable.place(x=0 , y=0)

        def return_page():
            controller.show_frame('ChooseBack')

        return_button = tk.Button(self, text="Orqaga", command=return_page,
                                  font=('Bernard MT Condensed', 15, 'bold'), fg="red", bg="#000")
        return_button.pack()

        in_money_label = tk.Label(self, text="Meva", font=('Bernard MT Condensed', 15, 'bold'),
                                  fg="pink", bg="black")
        in_money_label.place(x=100, y=100)
        in_money = tk.StringVar()

        in_money_entry = tk.Entry(self, textvariable=in_money, font=('Bernard MT Condensed', 15, 'bold'), fg="#555",
                                  bg="#999")
        in_money_entry.place(x=100, y=150)

        def choose_sabzavot():
            global new_cash
            if in_money.get() == "olma":
                new_cash = float(my_cash.get()) * float(5000)
                cash_label['text'] = new_cash
            elif in_money.get() == "uzum":
                new_cash = float(my_cash.get()) * float(7500)
                cash_label['text'] = new_cash
            elif in_money.get() == "banan":
                new_cash = float(my_cash.get()) * float(12500)
                cash_label['text'] = new_cash
            elif in_money.get() == "kivi":
                new_cash = float(my_cash.get()) * float(15000)
                cash_label['text'] = new_cash
            else:
                new_cash = int(my_cash.get())
                cash_label['text'] = new_cash

        cash_label = tk.Label(self, text="Miqdor(kg)", font=('Bernard MT Condensed', 15, 'bold'),
                              fg="pink", bg="black")
        cash_label.place(x=100, y=250)
        my_cash = tk.DoubleVar()
        cash_entry = tk.Entry(self, textvariable=my_cash, font=('Bernard MT Condensed', 15, 'bold'), fg="pink",
                              bg="#999")
        cash_entry.place(x=100, y=300)

        cash_label = tk.Label(self, font=('Bernard MT Condensed', 40, 'bold'),
                              fg="pink", bg="black")
        cash_label.place(x=100, y=550)

        cash_button = tk.Button(self, text="kiritish", command=choose_sabzavot,
                                font=('Bernard MT Condensed', 15, 'bold'), fg="pink", bg="black", width='25')
        cash_button.place(x=100, y=400)

        text1_label = tk.Label(self, text="olma:    5000", font=('Bernard MT Condensed', 25, 'bold'),
                               fg="#000", bg="#fff")
        text1_label.place(x=800, y=100)
        text2_label = tk.Label(self, text="uzum:    7500", font=('Bernard MT Condensed', 25, 'bold'),
                               fg="#000", bg="#fff")
        text2_label.place(x=800, y=200)
        text3_label = tk.Label(self, text="banan:   12500", font=('Bernard MT Condensed', 25, 'bold'),
                               fg="#000", bg="#fff")
        text3_label.place(x=800, y=300)
        text4_label = tk.Label(self, text="kivi:    15000", font=('Bernard MT Condensed', 25, 'bold'),
                               fg="#000", bg="#fff")
        text4_label.place(x=800, y=400)



if __name__== "__main__":
    app = SampleAPP()
    app.mainloop()

